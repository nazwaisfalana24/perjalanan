<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Siswa</title>
</head>
<body>
    <center>
    <table align="center">
        <tr>
            <td>Tanggal</td>
            <td>: {{$show->tanggal}}</td>
        </tr>
        <tr>
            <td>Jam</td>
            <td>: {{$show->jam}}</td>
        </tr>
        <tr>
            <td>Lokasi</td>
            <td>: {{$show->lokasi}}</td>
        </tr>
        <tr>
            <td>Suhu Tubuh</td>
            <td>: {{$show->suhu_tubuh}}</td>
        </tr>
        <tr>
            <td>Id User</td>
            <td>: {{$show->id_user}}</td>
        </tr>
    </table>
    <br>
    <a href="{{ url('/perjalanan') }}"> Kembali </button> 
</center>
</body>
</html>