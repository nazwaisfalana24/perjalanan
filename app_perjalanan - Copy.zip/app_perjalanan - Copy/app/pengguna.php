<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pengguna extends Model
{
    protected $table = 'users';
    protected $fillable = [
        'id',
        'nik',
        'nama',
        'email',
        'telp',
        'kota_id',
        'username', 
        'password',
        'confirm',
        'foto'
    ];

    protected $primaryKey = 'id';

    // public function perjalanan()
    // {
    //     return $this->hasMany('App\perjalanan');
    // }
    // public function kota()
    // {
    //     return $this->belongsTo('App\Kota');
    // }
}
