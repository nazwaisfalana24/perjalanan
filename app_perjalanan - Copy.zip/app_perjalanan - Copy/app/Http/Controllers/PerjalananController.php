<?php

namespace App\Http\Controllers;

use App\perjalanan;
use App\pengguna;
use App\user;
use Illuminate\Http\Request;

class PerjalananController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $perjalanan = perjalanan::all();
        return view ('perjalanan.index',compact('perjalanan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $perjalanan = perjalanan::all();
         $user = user::all();
         return view ('perjalanan.create', compact('perjalanan', 'user'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $value= [
            'tanggal'=>$request->tanggal,
            'jam'=>$request-> jam,
            'lokasi'=>$request-> lokasi,
            'suhu_tubuh'=>$request-> suhu_tubuh,
            'id_user'=>$request-> id_user
        ];
        perjalanan::create($value);
        return redirect('/perjalanan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\perjalanan  $perjalanan
     * @return \Illuminate\Http\Response
     */
    public function show( $id)
    {
        $ac = perjalanan::all($id);
        return view('perjalanan.show', compact('ac'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\perjalanan  $perjalanan
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $perjalanan = perjalanan::find($id);
        $user = pengguna::all();
        return view('perjalanan.edit', compact('perjalanan','user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\perjalanan  $perjalanan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $perjalanan = perjalanan::findOrFail($id);
        $jalan = [
            'tanggal'=>$request->tanggal,
            'jam'=>$request-> jam,
            'lokasi'=>$request-> lokasi,
            'suhu_tubuh'=>$request-> suhu_tubuh,
            'id_user'=>$request-> id_user
        ];
        $perjalanan->update($jalan);
        return redirect('/perjalanan');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\perjalanan  $perjalanan
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
        $perjalanan = perjalanan::destroy($id);
        return redirect('/perjalanan');
    }
}
